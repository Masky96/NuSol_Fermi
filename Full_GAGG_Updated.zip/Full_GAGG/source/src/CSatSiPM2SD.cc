//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// 
/// \file optical/CSat/src/CSatSiPM2SD.cc
/// \brief Implementation of the CSatSiPM2SD class
//
//
#include "CSatSiPM2SD.hh"

#include "CSatSiPM2Hit.hh"
#include "CSatAnalysis.hh"

#include "G4ios.hh"
#include "G4LogicalVolume.hh"
#include "G4ParticleDefinition.hh"
#include "G4ParticleTypes.hh"
#include "G4SDManager.hh"
#include "G4Step.hh"
#include "G4TouchableHistory.hh"
#include "G4Track.hh"
#include "G4VPhysicalVolume.hh"
#include "G4VProcess.hh"
#include "G4VTouchable.hh"
#include "G4ParticleTable.hh"
#include "G4SystemOfUnits.hh" 
#include "G4RunManager.hh"
#include "G4Gamma.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CSatSiPM2SD::CSatSiPM2SD(G4String name)
  : G4VSensitiveDetector(name)
  , fHitsCID(-1)
{
  fSiPM2Collection = nullptr;
  collectionName.insert("sipm2Collection");
  quanEff = new G4PhysicsOrderedFreeVector();
  
  std::ifstream datafile;
  datafile.open("quantumeff.dat");

  while(1)
    {
      G4double wlen, queff;

      datafile >> wlen >> queff;

      if(datafile.eof())
	break;

      //G4cout << wlen << " " << queff << G4endl;

      quanEff->InsertValues(wlen, queff/100);
    }
  datafile.close();

  //quanEff->SetSpline(true);
  
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

CSatSiPM2SD::~CSatSiPM2SD() {}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CSatSiPM2SD::Initialize(G4HCofThisEvent* hitsCE)
{
  fSiPM2Collection =
    new CSatSiPM2HitsCollection(SensitiveDetectorName, collectionName[0]);

  if(fHitsCID < 0)
  {
    fHitsCID = G4SDManager::GetSDMpointer()->GetCollectionID(fSiPM2Collection);
  }
  hitsCE->AddHitsCollection(fHitsCID, fSiPM2Collection);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4bool CSatSiPM2SD::ProcessHits(G4Step* aStep, G4TouchableHistory*) {
 

  if(aStep->GetTrack()->GetDefinition() != G4OpticalPhoton::OpticalPhotonDefinition()) 
    {
      return false;
    }



  //G4int evtID = G4RunManager::GetRunManager()->GetCurrentEvent()->GetEventID();
  //G4cout << "The Event ID is: " << evtID << G4endl;
  
  //G4int parentID = aStep->GetTrack()->GetParentID();

  //G4cout << "The Parent ID is: " << parentID << G4endl;

  
  aStep->GetTrack()->SetTrackStatus(fStopAndKill);

  G4TouchableHistory* theTouchable =
    (G4TouchableHistory*) (aStep->GetPreStepPoint()->GetTouchable());
  
  G4VPhysicalVolume* thePrePV = theTouchable->GetVolume(0);

  G4StepPoint* thePrePoint = aStep->GetPreStepPoint();
  

  CSatSiPM2Hit* sipm2Hit = new CSatSiPM2Hit(thePrePV);
  
  G4float mom = thePrePoint->GetMomentum().mag();
  G4float wavelength = (1.239841939*eV/mom)*1E+03*nm; 
  
  
  G4float timeG = aStep->GetTrack()->GetGlobalTime();

  
  if (G4UniformRand() < quanEff->Value(wavelength))
    {
  
  sipm2Hit->SetTimeG(timeG);
    }


  fSiPM2Collection->insert(sipm2Hit);

  
  return true;





}
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
