

#ifndef CSatAnalysis_h
#define CSatAnalysis_h 1

#include "g4root.hh"
//#include "g4xml.hh"

//G4int ntupleID;


#endif
