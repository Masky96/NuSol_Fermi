//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
/// \file optical/CSat/src/CSatMainVolume.cc
/// \brief Implementation of the CSatMainVolume class
//
//
#include "CSatMainVolume.hh"

#include "globals.hh"
#include "G4Box.hh"
#include "G4Colour.hh"
#include "G4LogicalSkinSurface.hh"
#include "G4LogicalBorderSurface.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4MaterialPropertiesTable.hh"
#include "G4OpticalSurface.hh"
#include "G4Sphere.hh"
#include "G4SystemOfUnits.hh"
#include "G4PhysicalConstants.hh"
#include "G4Tubs.hh"
#include "G4VisAttributes.hh"




//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......


CSatMainVolume::CSatMainVolume(G4RotationMatrix* pRot, const G4ThreeVector& tlate,
                             G4LogicalVolume* pMotherLogical, G4bool pMany,
                             G4int pCopyNo, CSatDetectorConstruction* c)
  // Pass info to the G4PVPlacement constructor
  : G4PVPlacement(pRot, tlate,
                  // Temp logical volume must be created here
                  new G4LogicalVolume(new G4Box("temp", 1, 1, 1),
                                      G4Material::GetMaterial("Vacuum"), "temp",
                                      0, 0, 0),
                  "fakeVolume", pMotherLogical, pMany, pCopyNo)
  , fConstructor(c)
  
{
  CopyValues();

  //Default Cosntants

 

  G4double lGAGG_x = 28*mm;
  G4double lGAGG_y = 28*mm;
  G4double lGAGG_z = 24*mm;

  G4double lQuartz_x = 28*mm;
  G4double lQuartz_y = 28*mm;
  G4double lQuartz_z = 10*mm;
  
  G4double pmArray1_x = 12.0*mm;
  G4double pmArray1_y = 12.0*mm;
  G4double pmArray1_z = 0.1*mm;
  
  G4double pmArray2_x = 12.0*mm;
  G4double pmArray2_y = 12.0*mm;
  G4double pmArray2_z = 0.1*mm;
  
  G4double pmArray3_x = 12.0*mm;
  G4double pmArray3_y = 12.0*mm;
  G4double pmArray3_z = 0.1*mm;
  
  G4double pmArray4_x = 12.0*mm;
  G4double pmArray4_y = 12.0*mm;
  G4double pmArray4_z = 0.1*mm;

  G4double al_GAGGx = lGAGG_x+0.3*mm;
  G4double al_GAGGy = lGAGG_y+0.3*mm;
  G4double al_GAGGz = lGAGG_z+0.15*mm;

  G4double Emptyx = 25*cm;
  G4double Emptyy = 25*cm;
  G4double Emptyz = 25*cm;

  //---------------------------
  
  G4double pmt_vetox = 5.2*cm;
  G4double pmt_vetoy = 5.2*cm;
  G4double pmt_vetoz = 3.9*cm;

  
  G4double air_pocketx = al_GAGGx + 1.35*mm;
  G4double air_pockety = al_GAGGy + 1.35*mm;
  G4double air_pocketz = al_GAGGz + 1.4*cm;

  
  G4double althinx = air_pocketx + 1.35*mm;
  G4double althiny = air_pockety + 1.35*mm;
  G4double althinz = air_pocketz + 1*mm;

  G4double fVeto_x = 5.15*cm;
  G4double fVeto_y = 5.15*cm;
  G4double fVeto_z = 4.5*cm;
  
  G4double housing_x = fVeto_x + 2. * 1*mm;
  G4double housing_y = fVeto_y + 2. * 1*mm;
  G4double housing_z = fVeto_z + 2. * 1*mm;

  G4double iron_shieldx = 8.3*cm;
  G4double iron_shieldy = 8.3*cm;
  G4double iron_shieldz = 12.5*cm;










  

  //Creating empty space so we can rotate the Iron 

  G4Box* emptyspace = new G4Box("empty", Emptyx/2., Emptyy/2., Emptyz/2.);
  G4LogicalVolume* emptyspaceLog = new G4LogicalVolume(emptyspace, G4Material::GetMaterial("Vacuum"), "spaceLog", 0,0,0);




  //Another empty because rotations are stupid
  femptyagain = new G4Box("emptyagain", (iron_shieldx+3*cm)/2,(iron_shieldy+3*cm)/2,(iron_shieldz+6*cm)/2);
  femptyagain_log = new G4LogicalVolume(femptyagain, G4Material::GetMaterial("Vacuum"), "emptylogagain", 0,0,0);


  G4RotationMatrix* rot = new G4RotationMatrix();
  rot->rotateY(450/10*deg);
  rot->rotateX(450/10*deg);

  
  new G4PVPlacement(rot,G4ThreeVector(0,0,0), femptyagain_log, "emptyspace", emptyspaceLog, false, 0);

  
  //Iron Shield Outside
  fIronShield = new G4Box("iron_shield", iron_shieldx/2., iron_shieldy/2., iron_shieldz/2.);

  fIron_log = new G4LogicalVolume(fIronShield, G4Material::GetMaterial("Tungsten Shield"),"iron_log", 0,0,0);

  

  
  new G4PVPlacement(0,G4ThreeVector(0,0,2.45*cm), fIron_log, "Shielding", femptyagain_log, false, 0);

  


  //AirGap between Shield and Detector

  fAirGap = new G4Box("air_gap", (housing_x+2*mm)/2.,(housing_y+2*mm)/2., (housing_z+ pmt_vetoz + 2*mm)/2.);

  fAirGap_log = new G4LogicalVolume(fAirGap, G4Material::GetMaterial("Air"), "air_gap", 0,0,0);

  new G4PVPlacement(0, G4ThreeVector(), fAirGap_log, "air_gap_shield", fIron_log,false,0);

  


  //*************************** housing and scintillator
  //Changing Things Around


  fVeto = new G4Box("Veto", fVeto_x/2., fVeto_y/2., fVeto_z/2.);


  fVeto_Log = new G4LogicalVolume(fVeto, G4Material::GetMaterial("Eljin"),"veto_log",0,0,0);



  fHousing_box =
    new G4Box("housing_box", housing_x / 2., housing_y / 2., housing_z / 2.);

  fHousing_log = new G4LogicalVolume(fHousing_box, G4Material::GetMaterial("Al"), "housing_log", 0, 0, 0);
  

  new G4PVPlacement(0,G4ThreeVector(0,0,0),fVeto_Log,"Veto_Scint",fHousing_log, false , 0); 

  new G4PVPlacement(0, G4ThreeVector(0,0,-pmt_vetoz/2.), fHousing_log, "housing_al",fAirGap_log,false,0);
  

  //----------------------------------------------------------------------------

  falumthin = new G4Box("alumthin", althinx/2., althiny/2., althinz/2.);

  falumthin_log = new G4LogicalVolume(falumthin, G4Material::GetMaterial("Al"), "alumthin",0,0,0);
 
  new G4PVPlacement(0, G4ThreeVector(), falumthin_log, "alumthin", fVeto_Log, false, 0);

  
  //------------------------------------------------------------------------------
  //Small Air Pocket for GAGG and PMT
  
  fairpocket = new G4Box("airpocket", air_pocketx/2., air_pockety/2., air_pocketz/2.);

  fair_log = new G4LogicalVolume(fairpocket, G4Material::GetMaterial("Air"),"air_log", 0, 0, 0);

  new G4PVPlacement(0,G4ThreeVector(),fair_log, "air_pocket", falumthin_log, false, 0);
  

  


   
  //Fixing Al outside.
  falumGAGG = new G4Box("alumGAGG", al_GAGGx/2., al_GAGGy/2.,al_GAGGz/2.);

  falumGAGG_log = new G4LogicalVolume(falumGAGG, G4Material::GetMaterial("Al"), "al_GAGG", 0,0,0);

  new G4PVPlacement(0, G4ThreeVector(0,0,0),falumGAGG_log, "alum_gagg", fair_log,false,0);



  //-----------------------------------------------------------------------------
  //GAGG Cystal 

  fScint_box =
    new G4Box("scint_box", lGAGG_x/ 2., lGAGG_y / 2., lGAGG_z / 2.);

  fScint_log   = new G4LogicalVolume(fScint_box, G4Material::GetMaterial("GAGG"),
                                   "scint_log", 0, 0, 0);

  new G4PVPlacement(0, G4ThreeVector(0, 0, (al_GAGGz-lGAGG_z)/2 ), fScint_log, "scintillator",falumGAGG_log, false, 0);



  //Quartz Cystal 

  fQuartz_box =
    new G4Box("Quartz_box", lQuartz_x/ 2., lQuartz_y / 2., lQuartz_z / 2.);

  fQuartz_log   = new G4LogicalVolume(fQuartz_box, G4Material::GetMaterial("Quartz"),"scint_log", 0, 0, 0);

  new G4PVPlacement(0, G4ThreeVector(0, 0, (7.1*millimeter) ), fQuartz_log, "scintillator",fScint_log, false, 0);
  




  // SiPM 1
  
  fSiPM1 = new G4Box("SiPM1_gagg", pmArray1_x/2., pmArray1_y/2.,(pmArray1_z)/2.);
  
  fSiPM1_log = new G4LogicalVolume(fSiPM1, G4Material::GetMaterial("Si"), "SiPM1_log");
  
  new G4PVPlacement(0, G4ThreeVector(7*millimeter, 7*millimeter, (lQuartz_z+pmArray1_z)/2.), fSiPM1_log, "SiPM1",fQuartz_log,false, 0);



  // SiPM 2
  
  fSiPM2 = new G4Box("SiPM2_gagg", pmArray2_x/2., pmArray2_y/2.,(pmArray2_z)/2.);
  
  fSiPM2_log = new G4LogicalVolume(fSiPM2, G4Material::GetMaterial("Si"), "SiPM2_log");
  
  new G4PVPlacement(0, G4ThreeVector(-7*millimeter, 7*millimeter, (lQuartz_z+pmArray2_z)/2.), fSiPM2_log, "SiPM2",fQuartz_log,false, 0);



  // SiPM 3
  
  fSiPM3 = new G4Box("SiPM3_gagg", pmArray3_x/2., pmArray3_y/2.,(pmArray3_z)/2.);
  
  fSiPM3_log = new G4LogicalVolume(fSiPM3, G4Material::GetMaterial("Si"), "SiPM3_log");
  
  new G4PVPlacement(0, G4ThreeVector(-7*millimeter, -7*millimeter, (lQuartz_z+pmArray3_z)/2.), fSiPM3_log, "SiPM3",fQuartz_log,false, 0);



  // SiPM 4
  
  fSiPM4 = new G4Box("SiPM4_gagg", pmArray4_x/2., pmArray4_y/2.,(pmArray4_z)/2.);
  
  fSiPM4_log = new G4LogicalVolume(fSiPM4, G4Material::GetMaterial("Si"), "SiPM4_log");
  
  new G4PVPlacement(0, G4ThreeVector(7*millimeter, -7*millimeter, (lQuartz_z+pmArray4_z)/2.), fSiPM4_log, "SiPM4",fQuartz_log,false, 0);


  fPhotocathV = new G4Box("photocath_veto",pmt_vetox/2., pmt_vetoy/2.,(pmt_vetoz)/2.);

  fPhotocathV_log = new G4LogicalVolume(fPhotocathV, G4Material::GetMaterial("Al"), "photocathV_log");
  

  G4RotationMatrix* rm_z = new G4RotationMatrix();
   rm_z->rotateY(180. * deg);
   G4double z = fVeto_z / 2.;  // back

   new G4PVPlacement(rm_z, G4ThreeVector(0,0,(z+(pmt_vetoz/2.))), fPhotocathV_log, "pmt_veto",fHousing_log, false, 0);
  
  
  VisAttributes();
  SurfaceProperties();

  SetLogicalVolume(emptyspaceLog);
  
  
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CSatMainVolume::CopyValues()
{
 
  fNx              = fConstructor->GetNX();
  fNy              = fConstructor->GetNY();
  fNz              = fConstructor->GetNZ();
  fOuterRadius_pmt = fConstructor->GetPMTRadius();
  fRefl            = fConstructor->GetHousingReflectivity();
}


//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void CSatMainVolume::VisAttributes()
{
 

  G4VisAttributes* gagg_VA = new G4VisAttributes(G4Colour(1.,1.,0.,0.5));
  gagg_VA->SetForceSolid(true);
  fScint_log->SetVisAttributes(gagg_VA);

  G4VisAttributes* quartz_VA = new G4VisAttributes(G4Colour(1.,1.,1.,0.5));
  quartz_VA->SetForceSolid(true);
  fQuartz_log->SetVisAttributes(quartz_VA);

  
  G4VisAttributes* sipm1_VA = new G4VisAttributes(G4Colour(1.,0.,0.,0.7));
  sipm1_VA->SetForceSolid(true);
  fSiPM1_log->SetVisAttributes(sipm1_VA);
  
  G4VisAttributes* sipm2_VA = new G4VisAttributes(G4Colour(0.,0.,0.,0.7));
  sipm2_VA->SetForceSolid(true);
  fSiPM2_log->SetVisAttributes(sipm2_VA);
  
  G4VisAttributes* sipm3_VA = new G4VisAttributes(G4Colour(1.,0.,1.,0.7));
  sipm3_VA->SetForceSolid(true);
  fSiPM3_log->SetVisAttributes(sipm3_VA);
  
  G4VisAttributes* sipm4_VA = new G4VisAttributes(G4Colour(1.,1.,0.,0.7));
  sipm4_VA->SetForceSolid(true);
  fSiPM4_log->SetVisAttributes(sipm4_VA);
  
  
   
 
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//Defining the surface properties to different materials.

void CSatMainVolume::SurfaceProperties()
{
  //Surface property to all aluminum portions.

  
  std::vector<G4double> ephoton = { 1.2398/.400 , 1.2398/.410 , 1.2398/.420 , 1.2398/.430 , 1.2398/.440 , 1.2398/.450 ,
				    1.2398/.460 , 1.2398/.470 , 1.2398/.480 , 1.2398/.490 , 1.2398/.500 , 1.2398/.510 ,
				    1.2398/.520 , 1.2398/.530 , 1.2398/.540 , 1.2398/.550 , 1.2398/.560 , 1.2398/.570 ,
				    1.2398/.580 , 1.2398/.590 , 1.2398/.600 , 1.2398/.610 , 1.2398/.620 , 1.2398/.630 ,
				    1.2398/.640 , 1.2398/.650 };
  
  //**Scintillator housing properties
  std::vector<G4double> reflectivity     = { fRefl, fRefl, fRefl, fRefl, fRefl, fRefl,
					     fRefl, fRefl, fRefl, fRefl, fRefl, fRefl,
					     fRefl, fRefl, fRefl, fRefl, fRefl, fRefl,
					     fRefl, fRefl, fRefl, fRefl, fRefl, fRefl,
					     fRefl, fRefl};
  
  std::vector<G4double> efficiency       = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
					     0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
					     0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
					     0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
					     0.0, 0.0};
  
  G4MaterialPropertiesTable* scintHsngPT = new G4MaterialPropertiesTable();
  scintHsngPT->AddProperty("REFLECTIVITY", ephoton, reflectivity);
  scintHsngPT->AddProperty("EFFICIENCY", ephoton, efficiency);
  G4OpticalSurface* OpScintHousingSurface =
    new G4OpticalSurface("HousingSurface", unified, polished, dielectric_metal);
  OpScintHousingSurface->SetMaterialPropertiesTable(scintHsngPT);



  
  
  //**Photocathode surface properties
  std::vector<G4double> photocath_EFF     = { 1., 1., 1., 1., 1., 1.,
					      1., 1., 1., 1., 1., 1.,
					      1., 1., 1., 1., 1., 1.,
					      1., 1., 1., 1., 1., 1.,
					      1.,1.};
  
  std::vector<G4double> photocath_ReR     = { 1.92, 1.92, 1.92, 1.92, 1.92, 1.92,
					      1.92, 1.92, 1.92, 1.92, 1.92, 1.92,
					      1.92, 1.92, 1.92, 1.92, 1.92, 1.92,
					      1.92, 1.92, 1.92, 1.92, 1.92, 1.92,
					      1.92, 1.92};
  
  std::vector<G4double> photocath_ImR     = { 1.69, 1.69, 1.69, 1.69, 1.69, 1.69,
					      1.69, 1.69, 1.69, 1.69, 1.69, 1.69,
					      1.69, 1.69, 1.69, 1.69, 1.69, 1.69,
					      1.69, 1.69, 1.69, 1.69, 1.69, 1.69,
					      1.69, 1.69};
  
  G4MaterialPropertiesTable* photocath_mt = new G4MaterialPropertiesTable();
  photocath_mt->AddProperty("EFFICIENCY", ephoton, photocath_EFF);
  photocath_mt->AddProperty("REALRINDEX", ephoton, photocath_ReR);
  photocath_mt->AddProperty("IMAGINARYRINDEX", ephoton, photocath_ImR);
  G4OpticalSurface* photocath_opsurf = new G4OpticalSurface(
    "photocath_opsurf", glisur, polished, dielectric_metal);
  photocath_opsurf->SetMaterialPropertiesTable(photocath_mt);


 






  
  //**Create logical skin surfaces
  new G4LogicalSkinSurface("photocath_surf", fHousing_log,
                           OpScintHousingSurface);

  new G4LogicalSkinSurface("photocathV_surf", fPhotocathV_log, photocath_opsurf);
  //new G4LogicalSkinSurface("photocathG_surf", fPhotocathG_log, photocath_opsurf);
  new G4LogicalSkinSurface("sipm1_surf", fSiPM1_log, photocath_opsurf);
  new G4LogicalSkinSurface("sipm2_surf", fSiPM2_log, photocath_opsurf);
  new G4LogicalSkinSurface("sipm3_surf", fSiPM3_log, photocath_opsurf);
  new G4LogicalSkinSurface("sipm4_surf", fSiPM4_log, photocath_opsurf);

  

  

  new G4LogicalSkinSurface("alumGAGG_surf", falumGAGG_log, OpScintHousingSurface);
  new G4LogicalSkinSurface("alumthin_surf", falumthin_log, OpScintHousingSurface); 

  
  
}

