# This copies a file to a new location/name and then replaces all instances
# of one string with another.
#
# BE CAREFUL because unintended matches can bork a file.
#


## Begin
num=2 # there are numbers in here and this will help

# First file
oldfile="/home/q557z543/Geant4/Full_GAGG_Aluminum/source/src/CSatSiPM1Hit.cc"
newfile='/home/q557z543/Geant4/Full_GAGG_Aluminum/source/src/CSatSiPM'"$num"'Hit.cc'

cp "$oldfile" "$newfile"
sed -i 's/SiPM1/SiPM'"$num"'/g' "$newfile" # Replace 
sed -i 's/sipm1/sipm'"$num"'/g' "$newfile"

# Different files, same number
oldfile="/home/q557z543/Geant4/Full_GAGG_Aluminum/source/src/CSatSiPM1SD.cc"
newfile='/home/q557z543/Geant4/Full_GAGG_Aluminum/source/src/CSatSiPM'"$num"'SD.cc'

cp "$oldfile" "$newfile"
sed -i 's/SiPM1/SiPM'"$num"'/g' "$newfile" # Replace 
sed -i 's/sipm1/sipm'"$num"'/g' "$newfile"

# Different files, same number
oldfile="/home/q557z543/Geant4/Full_GAGG_Aluminum/source/include/CSatSiPM1Hit.hh"
newfile='/home/q557z543/Geant4/Full_GAGG_Aluminum/source/include/CSatSiPM'"$num"'Hit.hh'

cp "$oldfile" "$newfile"
sed -i 's/SiPM1/SiPM'"$num"'/g' "$newfile" # Replace 
sed -i 's/sipm1/sipm'"$num"'/g' "$newfile"

# Different files, same number
oldfile="/home/q557z543/Geant4/Full_GAGG_Aluminum/source/include/CSatSiPM1SD.hh"
newfile='/home/q557z543/Geant4/Full_GAGG_Aluminum/source/include/CSatSiPM'"$num"'SD.hh'

cp "$oldfile" "$newfile"
sed -i 's/SiPM1/SiPM'"$num"'/g' "$newfile" # Replace 
sed -i 's/sipm1/sipm'"$num"'/g' "$newfile"


### Different Number
## Begin
num=3 # there are numbers in here and this will help

# First file
oldfile="/home/q557z543/Geant4/Full_GAGG_Aluminum/source/src/CSatSiPM1Hit.cc"
newfile='/home/q557z543/Geant4/Full_GAGG_Aluminum/source/src/CSatSiPM'"$num"'Hit.cc'

cp "$oldfile" "$newfile"
sed -i 's/SiPM1/SiPM'"$num"'/g' "$newfile" # Replace 
sed -i 's/sipm1/sipm'"$num"'/g' "$newfile"

# Different files, same number
oldfile="/home/q557z543/Geant4/Full_GAGG_Aluminum/source/src/CSatSiPM1SD.cc"
newfile='/home/q557z543/Geant4/Full_GAGG_Aluminum/source/src/CSatSiPM'"$num"'SD.cc'

cp "$oldfile" "$newfile"
sed -i 's/SiPM1/SiPM'"$num"'/g' "$newfile" # Replace 
sed -i 's/sipm1/sipm'"$num"'/g' "$newfile"

# Different files, same number
oldfile="/home/q557z543/Geant4/Full_GAGG_Aluminum/source/include/CSatSiPM1Hit.hh"
newfile='/home/q557z543/Geant4/Full_GAGG_Aluminum/source/include/CSatSiPM'"$num"'Hit.hh'

cp "$oldfile" "$newfile"
sed -i 's/SiPM1/SiPM'"$num"'/g' "$newfile" # Replace 
sed -i 's/sipm1/sipm'"$num"'/g' "$newfile"

# Different files, same number
oldfile="/home/q557z543/Geant4/Full_GAGG_Aluminum/source/include/CSatSiPM1SD.hh"
newfile='/home/q557z543/Geant4/Full_GAGG_Aluminum/source/include/CSatSiPM'"$num"'SD.hh'

cp "$oldfile" "$newfile"
sed -i 's/SiPM1/SiPM'"$num"'/g' "$newfile" # Replace 
sed -i 's/sipm1/sipm'"$num"'/g' "$newfile"



### Different Number
## Begin
num=4 # there are numbers in here and this will help

# First file
oldfile="/home/q557z543/Geant4/Full_GAGG_Aluminum/source/src/CSatSiPM1Hit.cc"
newfile='/home/q557z543/Geant4/Full_GAGG_Aluminum/source/src/CSatSiPM'"$num"'Hit.cc'

cp "$oldfile" "$newfile"
sed -i 's/SiPM1/SiPM'"$num"'/g' "$newfile" # Replace 
sed -i 's/sipm1/sipm'"$num"'/g' "$newfile"

# Different files, same number
oldfile="/home/q557z543/Geant4/Full_GAGG_Aluminum/source/src/CSatSiPM1SD.cc"
newfile='/home/q557z543/Geant4/Full_GAGG_Aluminum/source/src/CSatSiPM'"$num"'SD.cc'

cp "$oldfile" "$newfile"
sed -i 's/SiPM1/SiPM'"$num"'/g' "$newfile" # Replace 
sed -i 's/sipm1/sipm'"$num"'/g' "$newfile"

# Different files, same number
oldfile="/home/q557z543/Geant4/Full_GAGG_Aluminum/source/include/CSatSiPM1Hit.hh"
newfile='/home/q557z543/Geant4/Full_GAGG_Aluminum/source/include/CSatSiPM'"$num"'Hit.hh'

cp "$oldfile" "$newfile"
sed -i 's/SiPM1/SiPM'"$num"'/g' "$newfile" # Replace 
sed -i 's/sipm1/sipm'"$num"'/g' "$newfile"

# Different files, same number
oldfile="/home/q557z543/Geant4/Full_GAGG_Aluminum/source/include/CSatSiPM1SD.hh"
newfile='/home/q557z543/Geant4/Full_GAGG_Aluminum/source/include/CSatSiPM'"$num"'SD.hh'

cp "$oldfile" "$newfile"
sed -i 's/SiPM1/SiPM'"$num"'/g' "$newfile" # Replace 
sed -i 's/sipm1/sipm'"$num"'/g' "$newfile"

